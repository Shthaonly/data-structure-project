
package homework1;
import java.util.Scanner;


public class Duplicate {
    
     public static Boolean checkDuplicate(Node head) {
        Node start = head, current = head;

        while (current.getNext() != head) {
            Node inner = current.getNext();
            while (inner != head) {
                if (inner.getElement() == current.getElement()) {
                    return true;
                }
                inner = inner.getNext();
            }
            current = current.getNext();
        }
        return false;
    }
}
