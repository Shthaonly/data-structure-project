
package homework1;

import java.util.Scanner;
public class Cipher {
    
    /** START
       String cipherText =“”
       For (int i = 0; i< plaintext.length () ; i++)
          If (plaintext.charAt(i) == ‘ ‘)THEN
          ciphertext = ciphertext + ‘ ‘
          Else if (plaintext.charAt(i) + number > 122)
          cipherText = cipherText  + (char) (plaintext.charAt(i) + number -20)
          Else 
          CipherText = cipherText + (char) (plaintext.charAt(i) + number )
        End For 
   Return cipherText
   END */
    
    public static String encode(String plaintext, int number) {
        String cipherText = "";
        for (int i = 0; i < plaintext.length(); i++) {
            if (plaintext.charAt(i) == ' ') {
                cipherText = cipherText + ' ';
            } else if (plaintext.charAt(i) + number > 122) {
                cipherText = cipherText + (char) (plaintext.charAt(i) + number - 26);
            } else {
                cipherText = cipherText + (char) (plaintext.charAt(i) + number);
            }
        }
        return cipherText;
    }

    
    /** START 
        String originalText = "";

        for (int i = 0; i < cipherText.length(); i++) 
            if (cipherText.charAt(i) == ' ') THEN
                originalText = originalText + ' ';
             Else if (cipherText.charAt(i) - number < 97) 
                originalText = originalText + (char) (cipherText.charAt(i) - number + 26)
             Else 
                originalText = originalText + (char) ((cipherText.charAt(i) - number)
            End For
        
        Return originalText

       END */
    public static String decode(String cipherText, int number) {
        String originalText = "";
        for (int i = 0; i < cipherText.length(); i++) {
            if (cipherText.charAt(i) == ' ') {
                originalText = originalText + ' ';
            } else if (cipherText.charAt(i) - number < 97) {
                originalText = originalText + (char) (cipherText.charAt(i) - number + 26);
            } else {
                originalText = originalText + (char) ((cipherText.charAt(i) - number));
            }
        }
        return originalText;
    }
}
